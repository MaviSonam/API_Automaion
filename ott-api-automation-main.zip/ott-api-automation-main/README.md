API Phando
===================

### PHANDO Api automation
---
#### Summary:



#### System Requirement:

* JDK 1.8 or above
* Maven 4.0
* Eclipse or IDE of choice in case there is need to update the script. (optional)

#### Test Execution:

An API testing framework powered by TestNG and RestAssured, offering seamless test automation, comprehensive assertion capabilities, and simplified test configuration for RESTful APIs.

##### Executing the default tests as mentioned in the TestNG.xml

    mvn clean integration-test

##### Executing custom suite of tests (e.g. as defined in NewTestNG.xml)

    mvn clean integration-test -Dtestxml=TEST.xml

##### Executing a single test (e.g. Admin_Login_Layout_Test)

    mvn clean integration-test -Dtest=TEST


#### Result Files:	
The Test Execution Results will be stored in the following directory once the test has completed

##### TestNG Surefire reports
    ./target/surefire-reports/emailable-report.html (for single test suite)
	
